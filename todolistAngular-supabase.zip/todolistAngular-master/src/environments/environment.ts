export const environment = {
    production: false,
    supabaseUrl: 'https://bgvxattxkpamiycdxirt.supabase.co',
    supabaseKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJndnhhdHR4a3BhbWl5Y2R4aXJ0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzY0NDI4MDQsImV4cCI6MjA1MjAxODgwNH0.fhxkgZWzodXb_hl3cW8ibdBX-r5MCz7r8YUJ479Fay0',
}

