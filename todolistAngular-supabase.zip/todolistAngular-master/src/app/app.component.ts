import { Component, OnInit } from '@angular/core';
import { SupabaseService } from './supabase.service';
import { RouterOutlet, RouterModule } from '@angular/router';
import { TodoListComponent } from "./todolist/todolist.component";
import { AuthComponent } from './auth/auth.component';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  imports: [RouterModule, TodoListComponent, AuthComponent, CommonModule],
})

export class AppComponent implements OnInit {
  title = 'taskManager';
  session: any = null;

  constructor(private readonly supabase: SupabaseService) {}

  ngOnInit(): void {
    this.session = this.supabase.session;

    this.supabase.authChanges((_, session) => {
      this.session = session;
    });
  }
}
