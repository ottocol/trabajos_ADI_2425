// auth.guard.ts
import { inject } from '@angular/core';
import { Router, type CanActivateFn } from '@angular/router';
import { SupabaseService } from '../supabase.service';

export const authGuard: CanActivateFn = async (route, state) => {
  const supabase = inject(SupabaseService);
  const router = inject(Router);
  
  const { data: { session } } = await supabase.supabase.auth.getSession();
  
  if (session) {
    // Si está autenticado y trata de ir a /auth, redirigir a /todolist
    if (state.url === '/auth') {
      router.navigate(['/todolist']);
      return false;
    }
    return true;
  } else {
    // Si no está autenticado y trata de ir a /todolist, redirigir a /auth
    if (state.url === '/todolist') {
      router.navigate(['/auth']);
      return false;
    }
    return true;
  }
};