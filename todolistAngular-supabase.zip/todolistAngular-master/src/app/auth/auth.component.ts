import { Component, inject } from '@angular/core';
import { FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';
import { SupabaseService } from '../supabase.service';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-auth',
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.css'],
  standalone: true,
  imports: [
    ReactiveFormsModule, 
    RouterModule,        
    CommonModule         
  ]
})
export class AuthComponent {
  loading = false;
  builder = inject(FormBuilder);

  signInForm = this.builder.group({
    email: this.builder.control('', Validators.compose([Validators.email, Validators.required])),
    password: this.builder.control('', Validators.compose([Validators.required]))
  });

  signUpForm = this.builder.group({
    email: this.builder.control('', Validators.compose([Validators.email, Validators.required])),
    password: this.builder.control('', Validators.compose([Validators.required, Validators.minLength(6)]))
  });

  constructor(
    private readonly supabase: SupabaseService,
    private readonly router: Router,
  ) {
    this.supabase.supabase.auth.getSession().then(({ data: { session } }) => {
      if (session) {
        this.router.navigate(['/todolist']);
      }
    });
  
    this.supabase.supabase.auth.onAuthStateChange((event, session) => {
      if (event === 'SIGNED_IN' && session) {
        this.router.navigate(['/todolist']);
      }
    });
  }

  async onLoginSubmit(): Promise<void> {
    try {
      this.loading = true;
      const email = this.signInForm.value.email as string;
      const password = this.signInForm.value.password as string;
      const { error } = await this.supabase.signInWithPassword(email, password);
      if (error) throw error;
    } catch(error) {
      if(error instanceof Error) {
        alert(error.message);
      }
    } finally {
      this.signInForm.reset();
      this.loading = false;
    }
  }

  async onRegisterSubmit(): Promise<void> {
    try {
      this.loading = true;
      const email = this.signUpForm.value.email as string;
      const password = this.signUpForm.value.password as string;
      const { error } = await this.supabase.signUpWithPassword(email, password);
      if (error) throw error;
      alert('Registro exitoso. Confirma tu cuenta desde tu correo.');
    } catch(error) {
      if(error instanceof Error) {
        alert(error.message);
      }
    } finally {
      this.signUpForm.reset();
      this.loading = false;
    }
  }
}

