import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { supabase } from '../supabase.client';
import { SupabaseService } from '../supabase.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-todolist',
  templateUrl: './todolist.component.html',
  styleUrls: ['./todolist.component.css'],
  standalone: true,
  imports: [FormsModule, CommonModule]
})
export class TodoListComponent implements OnInit {
  tareas_completadas = 0;
  nombre: string = '';
  descripcion: string = '';
  userId: string | undefined;
  tasks: {
    id: number;
    nombre: string;
    descripcion: string;
    completada: boolean;
    user_id: string;
  }[] = [];
  selectedTask: { id: number; nombre: string; descripcion: string; completada: boolean } | null = null;

  constructor(
    private supabaseService: SupabaseService,
    private router: Router
  ) {}

  truncate(value: number): number {
    return Math.floor(value);
  }

  async ngOnInit(): Promise<void> {
    const session = await supabase.auth.getSession();
    this.userId = session.data.session?.user.id;

    try {
      const { data, error } = await supabase
        .from('tasks')
        .select()
        .eq('user_id', this.userId);

      if (error) {
        console.error('Error al recuperar las tareas en Supabase:', error.message);
      } else if (data) {
        this.tasks = data;
        this.getTasksCompleted();
      }
    } catch (error) {
      console.error('Error al conectarse a Supabase:', error);
    }
  }

  async addTask(): Promise<void> {
    if (this.nombre.trim() && this.descripcion.trim() && this.userId) {
      const task = {
        nombre: this.nombre.trim(),
        descripcion: this.descripcion.trim(),
        completada: false,
        user_id: this.userId
      };

      try {
        const { data, error } = await supabase
          .from('tasks')
          .insert([task])
          .select();

        if (error) {
          console.error('Error al guardar la tarea en Supabase:', error.message);
        } else if (data && data.length > 0) {
          this.tasks.push(data[0]);
        }
        this.nombre = '';
        this.descripcion = '';
      } catch (error) {
        console.error('Error al conectarse a Supabase:', error);
      }
    }
  }

  async toggleTask(index: number, task: any): Promise<void> {
    this.tasks[index].completada = !this.tasks[index].completada;
    try {
      const { error } = await supabase
        .from('tasks')
        .update({ completada: this.tasks[index].completada })
        .eq('id', task.id)
        .eq('user_id', this.userId);

      this.getTasksCompleted();
      if (error) {
        console.error('Error al actualizar la tarea en Supabase:', error.message);
      }
    } catch (error) {
      console.error('Error al marcar como completada:', error);
    }
  }

  async removeTask(index: number, task: any): Promise<void> {
    try {
      const { error } = await supabase
        .from('tasks')
        .delete()
        .eq('id', task.id)
        .eq('user_id', this.userId);

      if (error) {
        console.error('Error al borrar la tarea en Supabase:', error.message);
      } else {
        this.tasks.splice(index, 1);
        this.getTasksCompleted();
      }
    } catch (error) {
      console.error('Error al borrar la tarea:', error);
    }
  }

  selectTask(task: any): void {
    this.selectedTask = task;
  }

  getTasksCompleted(): void {
    this.tareas_completadas = this.tasks.filter(task => task.completada).length;
  }

  async logout() {
    try {
      const { error } = await this.supabaseService.signOut();
      if (error) throw error;
    } catch (error) {
      console.error('Error cerrando sesión:', error);
      alert('Error al cerrar sesión. Inténtalo de nuevo.');
    }
  }
}