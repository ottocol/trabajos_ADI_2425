import { Injectable } from '@angular/core';
import {
  AuthChangeEvent,
  AuthSession,
  createClient,
  Session,
  SupabaseClient,
  User,
} from '@supabase/supabase-js'

import { environment } from '../environments/environment'

export interface Profile {
  id?: string
  username: string
}


@Injectable({
  providedIn: 'root'
})

export class SupabaseService {
  public supabase: SupabaseClient
  _session: AuthSession | null = null

  constructor() { 
    this.supabase = createClient(environment.supabaseUrl, environment.supabaseKey)
  }

  get session() {
    this.supabase.auth.getSession().then(({ data }) => {
      this._session = data.session
    })
    return this._session
  }

  

  profile(user: User) {
    return this.supabase
      .from('profiles')
      .select(`username`)
      .eq('id', user.id)
      .single()
  }

  authChanges(callback: (event: AuthChangeEvent, session: Session | null) => void) {
    return this.supabase.auth.onAuthStateChange(callback)
  }

  async signInWithPassword(email: string, password: string) {
  return await this.supabase.auth.signInWithPassword({
    email,
    password
  });
  }

  async signUpWithPassword(email:string, password:string){
    return await this.supabase.auth.signUp({
      email,
      password
    });
  }


  signOut() {
    return this.supabase.auth.signOut()
  }


}