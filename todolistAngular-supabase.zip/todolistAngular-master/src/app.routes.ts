import {Routes} from '@angular/router'
import { AuthComponent } from './app/auth/auth.component'
import { TodoListComponent } from './app/todolist/todolist.component'
import { authGuard } from './app/auth/auth.guard';


export const routes: Routes = [
    { path: 'auth', component: AuthComponent },
    { path: 'todolist', component: TodoListComponent},
    { path: '', redirectTo: '/auth', pathMatch: 'full' },
    { path: '**', redirectTo: '/auth' },
];