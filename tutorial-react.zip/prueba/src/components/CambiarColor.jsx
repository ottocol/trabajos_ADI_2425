import React from 'react';

class CambiarColor extends React.Component {
  constructor(props) {
    super(props);
    this.state = { color: 'rojo' };
  }

  cambiarColor = () => {
    this.setState({ color: this.state.color === 'rojo' ? 'azul' : 'rojo' });
  };

  render() {
    return (
      <div>
        <p style={{ color: this.state.color }}>Texto en {this.state.color}</p>
        <button onClick={this.cambiarColor}>Cambiar color</button>
      </div>
    );
  }
}

export default CambiarColor;
