function Footer() {
  return <footer>Este es el pie de página</footer>;
}

export default Footer;
