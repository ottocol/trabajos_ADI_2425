import { useState, useEffect } from 'react';

function Temporizador() {
  const [segundos, setSegundos] = useState(0);

  useEffect(() => {
    // Configura un temporizador que incrementa los segundos cada segundo
    const interval = setInterval(() => {
      setSegundos((prevSegundos) => prevSegundos + 1);
    }, 1000);

    // Limpieza del temporizador cuando el componente se desmonta
    return () => {
      clearInterval(interval);
      console.log('Temporizador limpiado');
    };
  }, []); // Se ejecuta solo al montar el componente

  return (
    <div>
      <h1>Segundos transcurridos: {segundos}</h1>
      <button onClick={() => setSegundos(0)}>Reiniciar</button>
    </div>
  );
}

export default Temporizador;
