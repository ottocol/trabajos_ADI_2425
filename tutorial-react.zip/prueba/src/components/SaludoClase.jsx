import React from 'react';
import PropTypes from 'prop-types';

class SaludoClase extends React.Component {
  render() {
    return <h2>Hola, {this.props.nombre}!</h2>;
  }
}

SaludoClase.propTypes = {
  nombre: PropTypes.string.isRequired,
};

export default SaludoClase;
