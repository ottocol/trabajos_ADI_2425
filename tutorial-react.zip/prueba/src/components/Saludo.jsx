function Saludo() {
    return <h1>¡Hola, esta es una prueba de componente funcional!</h1>;
}


export default Saludo;
