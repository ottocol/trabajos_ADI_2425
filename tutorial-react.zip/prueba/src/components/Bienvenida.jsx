import PropTypes from 'prop-types';

function Bienvenida(props) {
  return <h1>¡Hola, {props.nombre}!</h1>;
}

// Validamos de las props
Bienvenida.propTypes = {
  nombre: PropTypes.string.isRequired,
};

export default Bienvenida;
