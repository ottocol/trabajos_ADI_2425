import { useState } from 'react';

function MostrarTexto() {
  const [visible, setVisible] = useState(true);

  return (
    <div>
      {visible && <p>¡Hola, mundo!</p>}
      <button onClick={() => setVisible(!visible)}>
        {visible ? 'Ocultar' : 'Mostrar'} texto
      </button>
    </div>
  );
}

export default MostrarTexto;
