function Header() {
  return <header>Este es el encabezado</header>;
}

export default Header;
