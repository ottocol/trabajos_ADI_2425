function Main() {
  return <main>Este es el contenido principal</main>;
}

export default Main;
