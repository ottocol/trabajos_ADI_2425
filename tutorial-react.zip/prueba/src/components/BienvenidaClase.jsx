import React from 'react';
import PropTypes from 'prop-types';


class BienvenidaClase extends React.Component {
  render() {
    return <h1>¡Hola, {this.props.nombre}!</h1>;
  }
}

// Validamos de las props
BienvenidaClase.propTypes = {
    nombre: PropTypes.string.isRequired, 
  };

export default BienvenidaClase;
