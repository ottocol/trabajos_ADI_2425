import Temporizador from './components/Temporizador';

function App() {
  return (
    <div>
      <h2>Ejemplo de Temporizador con useEffect</h2>
      <Temporizador />
    </div>
  );
}

export default App;
