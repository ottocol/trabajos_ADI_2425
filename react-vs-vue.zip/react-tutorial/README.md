# Lista de Tareas con React

Este proyecto implementa una **Lista de Tareas (To-Do List)** utilizando **React**, una biblioteca de JavaScript para construir interfaces de usuario. Permite añadir y eliminar tareas dinámicamente, mostrando cómo React maneja el estado y los eventos.

---

## **Descripción**
La aplicación permite:
- Añadir tareas a una lista.
- Eliminar tareas de la lista.

### **Tecnologías Utilizadas**
- **React**: Biblioteca de JavaScript para construir interfaces de usuario.
- **useState**: Hook para manejar el estado local de las tareas.

---

## **Estructura del Proyecto**
- `App.js`: Contiene la lógica principal de la lista de tareas.
- `App.css`: Define los estilos opcionales de la aplicación.

---

## **Instrucciones para Ejecutar**
**Instalar las dependencias:**
   ```bash
   npm install
   ```
**Iniciar el servidor de desarrollo:**
   ```bash
   npm start
   ```

4. La aplicación estará disponible en `http://localhost:3000`.

---

## **Referencias**
- [React Documentation](https://react.dev/)
