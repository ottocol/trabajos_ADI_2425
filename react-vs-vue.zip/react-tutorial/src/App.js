import React, { useState } from 'react';

function App() {
  const [tasks, setTasks] = useState([]); // Estado para las tareas
  const [newTask, setNewTask] = useState(''); // Estado para la nueva tarea

  const addTask = () => {
    if (newTask.trim() === '') return; // No permitir tareas vacías
    setTasks([...tasks, newTask]); // Agregar la nueva tarea
    setNewTask(''); // Limpiar el input
  };

  const deleteTask = (index) => {
    setTasks(tasks.filter((_, i) => i !== index)); // Eliminar tarea por índice
  };

  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Lista de Tareas (React)</h1>
      <input
        type="text"
        value={newTask}
        onChange={(e) => setNewTask(e.target.value)}
        placeholder="Escribe una tarea"
      />
      <button onClick={addTask}>Añadir</button>
      <ul>
        {tasks.map((task, index) => (
          <li key={index}>
            {task} <button onClick={() => deleteTask(index)}>Eliminar</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
