<template>
  <div style="text-align: center; margin-top: 50px;">
    <h1>Lista de Tareas (Vue)</h1>
    <input
      v-model="newTask"
      type="text"
      placeholder="Escribe una tarea"
    />
    <button @click="addTask">Añadir</button>
    <ul>
      <li v-for="(task, index) in tasks" :key="index">
        {{ task }} <button @click="deleteTask(index)">Eliminar</button>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  data() {
    return {
      tasks: [], // Lista de tareas
      newTask: '' // Tarea nueva
    };
  },
  methods: {
    addTask() {
      if (this.newTask.trim() === '') return;
      this.tasks.push(this.newTask); // Añadir nueva tarea
      this.newTask = ''; // Limpiar el input
    },
    deleteTask(index) {
      this.tasks.splice(index, 1); // Eliminar tarea por índice
    }
  }
};
</script>

<style>
button {
  margin-left: 10px;
  padding: 5px 10px;
  background-color: #28a745;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

button:hover {
  background-color: #218838;
}

input {
  padding: 5px;
  border: 1px solid #ccc;
  border-radius: 5px;
}
</style>
