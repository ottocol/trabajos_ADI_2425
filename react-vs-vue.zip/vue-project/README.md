# Lista de Tareas con Vue.js

Este proyecto implementa una **Lista de Tareas (To-Do List)** utilizando **Vue.js**, un framework progresivo de JavaScript. Permite añadir y eliminar tareas dinámicamente, mostrando cómo funciona el manejo de datos y eventos en Vue.

---

## **Descripción**
La aplicación permite:
- Añadir tareas a una lista.
- Eliminar tareas de la lista.

### **Tecnologías Utilizadas**
- **Vue.js**: Framework progresivo de JavaScript.
- **v-model**: Para la vinculación de datos bidireccional.
- **v-for**: Para renderizar dinámicamente las tareas.

---

## **Estructura del Proyecto**
- `App.vue`: Contiene la lógica principal de la lista de tareas.
- `style` (dentro de `App.vue`): Define los estilos opcionales de la aplicación.

---

## **Instrucciones para Ejecutar**

**Instalar las dependencias:**
   ```bash
   npm install
   ```
Iniciar el servidor de desarrollo:**
   ```bash
   npm run dev
   ```

4. La aplicación estará disponible en `http://localhost:8080`.

---

## **Referencias**
- [Vue.js Documentation](https://vuejs.org/)
