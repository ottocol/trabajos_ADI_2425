import { Injectable } from '@angular/core';
import { auth, db } from '../app.component';  // Importamos las instancias de Firebase desde app.component.ts
import { doc, collection, query, getDoc, getDocs, setDoc, addDoc, deleteDoc, where } from 'firebase/firestore';

@Injectable({
  providedIn: 'root'
})
export class ListaService {

  constructor() { }

  // Obtener los elementos de la base de datos
  async getItems() {
    const user = auth.currentUser;  // Usamos auth que ya está configurado
    if (!user) throw new Error("Usuario no autentificado");

    const q = query(collection(db, "items"), where('uid', '==', user.uid));
    const snapshot = await getDocs(q);
    const results = snapshot.docs.map(item => ({
      id: item.id,
      ...item.data()
    }));
    return results;
  }

  // Añadir un nuevo item
  async addItem(nombre: string) {
    const user = auth.currentUser;
    if (!user) throw new Error("Usuario no autentificado");

    const nuevo = { nombre: nombre, uid: user.uid, comprado: false };
    const newRef = await addDoc(collection(db, "items"), nuevo);
    return { id: newRef.id, ...nuevo };
  }

  // Marcar un item como comprado
  async setItemComprado(id: string, comprado: boolean) {
    const user = auth.currentUser;
    if (!user) throw new Error("Usuario no autentificado");

    const itemRef = doc(db, "items", id);
    const ok = await this.itemExisteYHayPermisos(itemRef);
    if (ok) {
      await setDoc(itemRef, { comprado: comprado }, { merge: true });
    }
  }

  // Actualizar el nombre de un item
  async updateItem(id: string, nuevoNombre: string) {
    const user = auth.currentUser;
    if (!user) throw new Error("Usuario no autentificado");

    const itemRef = doc(db, "items", id);
    const ok = await this.itemExisteYHayPermisos(itemRef);
    if (ok) {
      await setDoc(itemRef, { nombre: nuevoNombre }, { merge: true });
    }
  }

  // Eliminar un item
  async deleteItem(id: string) {
    const user = auth.currentUser;
    if (!user) throw new Error("Usuario no autentificado");

    const itemRef = doc(db, "items", id);
    const ok = await this.itemExisteYHayPermisos(itemRef);
    if (ok) {
      await deleteDoc(itemRef);
    }
  }

  // Verificar si el item existe y si el usuario tiene permisos
  private async itemExisteYHayPermisos(ref: any) {
    const itemSnapshot = await getDoc(ref);
    if (!itemSnapshot.exists()) throw new Error("El item no existe");
    const data = itemSnapshot.data() as { uid: string };
    const currentUser = auth.currentUser;
    if (!currentUser) throw new Error("Usuario no autentificado");
    if (data.uid !== currentUser.uid) throw new Error("No tienes permisos");
    return true;
  }
}
