import { Injectable } from '@angular/core';
import { auth } from '../app.component';
import { signInWithEmailAndPassword, signOut } from 'firebase/auth';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  constructor() {}

  // Función para iniciar sesión
  login(email: string, password: string) {
    return signInWithEmailAndPassword(auth, email, password);
  }

  // Función para cerrar sesión
  logout() {
    return signOut(auth);
  }

  // Función para obtener el usuario actual
  getUser() {
    return auth.currentUser;
  }
}

