import { Component, OnInit } from '@angular/core';
import { ListaService } from '../../services/lista.service';
import { AuthService } from '../../services/auth.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-lista',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './lista.component.html',
  styleUrls: ['./lista.component.css']
})
export class ListaComponent implements OnInit {
  items: any[] = [];

  constructor(private listaService: ListaService, private authservice: AuthService) {}

  ngOnInit() {
    this.listaService.getItems().then(data => {
      this.items = data;
    });
  }

  addItem(nombre: string) {
    if (nombre.trim() === '') return; 
    this.listaService.addItem(nombre).then((item) => {
      this.items.push(item); 
      console.log('Item añadido');
    });
  }

  deleteItem(id: string) {
    this.listaService.deleteItem(id).then(() => {
      this.items = this.items.filter((item) => item.id !== id);
      console.log('Item eliminado');
    });
  }
  logout(){
    this.authservice.logout();
  }
}
