import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';
import { initializeApp } from 'firebase/app';
import { getAuth, onAuthStateChanged, connectAuthEmulator } from 'firebase/auth';
import { getFirestore, connectFirestoreEmulator } from 'firebase/firestore';
import { environment } from '../environments/environment';
import { ListaComponent } from './components/lista/lista.component';
import { LoginComponent } from './components/login/login.component';

// Inicializa Firebase
const app = initializeApp(environment.firebase);

// Configura Firebase Auth y Firestore
export const auth = getAuth(app);  // Exportamos auth
export const db = getFirestore(app);  // Exportamos db

if (!environment.production) {    
  connectAuthEmulator(auth, "http://127.0.0.1:9099");
  connectFirestoreEmulator(db, "127.0.0.1", 8080);
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, CommonModule, ListaComponent, LoginComponent], // Asegúrate de que CommonModule esté importado aquí
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'lista-compra-angular';
  hay_login: boolean = false;

  constructor() {
    onAuthStateChanged(auth, (user: any) => {
      console.log(user);
      this.hay_login = user != null;
    });
  }
}
