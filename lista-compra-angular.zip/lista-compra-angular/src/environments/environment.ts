export const environment = {
    firebase: {
        apiKey: "AIzaSyDdHgtEz6Wk-4xJ6hZoIieSmQy5yJHmaOc",
        authDomain: "adi-prac1.firebaseapp.com",
        projectId: "adi-prac1",
        storageBucket: "adi-prac1.firebasestorage.app",
        messagingSenderId: "1008345514478",
        appId: "1:1008345514478:web:f2499c4043e42562fc4eff"
    },
    production: false
  };
  