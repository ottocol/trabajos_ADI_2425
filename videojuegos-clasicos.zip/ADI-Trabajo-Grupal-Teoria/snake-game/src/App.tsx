import React from 'react';
import SnakeGame from './components/SnakeGame';

function App() {
  return (
    <div className="min-h-screen bg-gray-900">
      <SnakeGame />
    </div>
  );
}

export default App;