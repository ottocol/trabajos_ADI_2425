import React, { useState, useEffect, useCallback } from 'react';
import { ArrowUp, ArrowDown, ArrowLeft, ArrowRight, Gamepad2 } from 'lucide-react';
import { 
  GRID_SIZE, 
  CELL_SIZE, 
  INITIAL_SPEED, 
  SPEED_INCREASE,
  INITIAL_POSITION,
  INITIAL_FOOD_POSITION,
  Direction 
} from './types';
import { useSnakeLogic } from './hooks/useSnakeLogic';
import { useGameControls } from './hooks/useGameControls';
import { generateFood } from './utils/foodUtils';

export default function SnakeGame() {
  const [food, setFood] = useState(INITIAL_FOOD_POSITION);
  const [gameOver, setGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const [speed, setSpeed] = useState(INITIAL_SPEED);
  const [isPaused, setIsPaused] = useState(false);

  const handleGameOver = useCallback(() => {
    setGameOver(true);
  }, []);

  const { snake, setSnake, moveSnake } = useSnakeLogic(handleGameOver);
  const { direction, handleDirectionChange, processNextDirection } = useGameControls('RIGHT');

  const resetGame = () => {
    setSnake([INITIAL_POSITION]);
    handleDirectionChange('RIGHT');
    setGameOver(false);
    setScore(0);
    setSpeed(INITIAL_SPEED);
    setFood(generateFood([INITIAL_POSITION]));
    setIsPaused(false);
  };

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.key === ' ') {
        setIsPaused((prev) => !prev);
        return;
      }

      if (gameOver) {
        resetGame();
        return;
      }

      const keyDirections: { [key: string]: Direction } = {
        ArrowUp: 'UP',
        ArrowDown: 'DOWN',
        ArrowLeft: 'LEFT',
        ArrowRight: 'RIGHT',
      };

      if (keyDirections[e.key]) {
        handleDirectionChange(keyDirections[e.key]);
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [handleDirectionChange, gameOver]);

  useEffect(() => {
    if (gameOver || isPaused) return;

    const gameLoop = setInterval(() => {
      processNextDirection();
      moveSnake(direction, food);

      // Check if snake ate food
      const head = snake[0];
      if (head.x === food.x && head.y === food.y) {
        setScore((prev) => prev + 10);
        setSpeed((prev) => Math.max(prev - SPEED_INCREASE, 50));
        setFood(generateFood(snake));
      }
    }, speed);

    return () => clearInterval(gameLoop);
  }, [direction, food, gameOver, isPaused, moveSnake, processNextDirection, snake, speed]);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-900 text-white">
      <div className="mb-4 flex items-center gap-2">
        <Gamepad2 className="w-6 h-6" />
        <h1 className="text-2xl font-bold">Snake Game</h1>
      </div>
      
      <div className="mb-4 flex gap-4">
        <div className="text-lg">Score: {score}</div>
        <button
          onClick={() => setIsPaused((prev) => !prev)}
          className="px-4 py-1 bg-blue-600 rounded hover:bg-blue-700 transition"
        >
          {isPaused ? 'Resume' : 'Pause'}
        </button>
      </div>

      <div
        className="relative bg-gray-800 border-2 border-gray-700"
        style={{
          width: GRID_SIZE * CELL_SIZE,
          height: GRID_SIZE * CELL_SIZE,
        }}
      >
        {snake.map((segment, index) => (
          <div
            key={index}
            className="absolute bg-green-500 rounded-sm"
            style={{
              width: CELL_SIZE - 2,
              height: CELL_SIZE - 2,
              left: segment.x * CELL_SIZE,
              top: segment.y * CELL_SIZE,
              transition: 'all 0.1s',
            }}
          />
        ))}
        <div
          className="absolute bg-red-500 rounded-full"
          style={{
            width: CELL_SIZE - 2,
            height: CELL_SIZE - 2,
            left: food.x * CELL_SIZE,
            top: food.y * CELL_SIZE,
          }}
        />
      </div>

      {gameOver && (
        <div className="mt-4 text-center">
          <h2 className="text-xl font-bold text-red-500 mb-2">Game Over!</h2>
          <button
            onClick={resetGame}
            className="px-4 py-2 bg-green-600 rounded hover:bg-green-700 transition"
          >
            Play Again
          </button>
        </div>
      )}

      <div className="mt-6 grid grid-cols-3 gap-2">
        <div />
        <button
          onClick={() => !isPaused && handleDirectionChange('UP')}
          className="p-2 bg-gray-700 rounded hover:bg-gray-600 transition flex justify-center"
        >
          <ArrowUp />
        </button>
        <div />
        <button
          onClick={() => !isPaused && handleDirectionChange('LEFT')}
          className="p-2 bg-gray-700 rounded hover:bg-gray-600 transition flex justify-center"
        >
          <ArrowLeft />
        </button>
        <button
          onClick={() => !isPaused && handleDirectionChange('DOWN')}
          className="p-2 bg-gray-700 rounded hover:bg-gray-600 transition flex justify-center"
        >
          <ArrowDown />
        </button>
        <button
          onClick={() => !isPaused && handleDirectionChange('RIGHT')}
          className="p-2 bg-gray-700 rounded hover:bg-gray-600 transition flex justify-center"
        >
          <ArrowRight />
        </button>
      </div>

      <div className="mt-6 text-sm text-gray-400">
        Use arrow keys to move • Space to pause • Click buttons for mobile
      </div>
    </div>
  );
}