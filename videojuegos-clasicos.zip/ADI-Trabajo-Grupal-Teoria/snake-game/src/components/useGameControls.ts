import { useState, useCallback } from 'react';
import { Direction } from './types';

export function useGameControls(initialDirection: Direction) {
  const [direction, setDirection] = useState<Direction>(initialDirection);
  const [nextDirection, setNextDirection] = useState<Direction | null>(null);

  const isValidDirectionChange = (current: Direction, next: Direction): boolean => {
    const invalidCombinations = {
      UP: 'DOWN',
      DOWN: 'UP',
      LEFT: 'RIGHT',
      RIGHT: 'LEFT',
    };
    return invalidCombinations[current] !== next;
  };

  const handleDirectionChange = useCallback((newDirection: Direction) => {
    setDirection((currentDirection) => {
      if (isValidDirectionChange(currentDirection, newDirection)) {
        // Queue the next direction change
        setNextDirection(newDirection);
        return currentDirection;
      }
      return currentDirection;
    });
  }, []);

  const processNextDirection = useCallback(() => {
    if (nextDirection && isValidDirectionChange(direction, nextDirection)) {
      setDirection(nextDirection);
      setNextDirection(null);
    }
  }, [direction, nextDirection]);

  return {
    direction,
    setDirection,
    handleDirectionChange,
    processNextDirection,
  };
}