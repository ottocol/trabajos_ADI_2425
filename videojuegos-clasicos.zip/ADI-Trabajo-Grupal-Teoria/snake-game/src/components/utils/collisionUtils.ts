import { Position, GRID_SIZE } from '../types';

export const isWallCollision = (position: Position): boolean => {
  return (
    position.x < 0 || 
    position.x >= GRID_SIZE || 
    position.y < 0 || 
    position.y >= GRID_SIZE
  );
};

export const isSelfCollision = (head: Position, body: Position[]): boolean => {
  return body.slice(1).some(segment => 
    segment.x === head.x && segment.y === head.y
  );
};

export const isCollision = (head: Position, body: Position[]): boolean => {
  return isWallCollision(head) || isSelfCollision(head, body);
};