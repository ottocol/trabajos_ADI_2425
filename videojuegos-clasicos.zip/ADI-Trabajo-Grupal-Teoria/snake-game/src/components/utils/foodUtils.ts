import { Position, GRID_SIZE } from '../types';

export const generateFood = (snake: Position[]): Position => {
  let newFood: Position;
  
  do {
    newFood = {
      x: Math.floor(Math.random() * GRID_SIZE),
      y: Math.floor(Math.random() * GRID_SIZE),
    };
  } while (snake.some(segment => 
    segment.x === newFood.x && segment.y === newFood.y
  ));
  
  return newFood;
};