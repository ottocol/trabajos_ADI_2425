import { Position, Direction } from '../types';

export const getNextPosition = (current: Position, direction: Direction): Position => {
  const movements = {
    UP: { x: 0, y: -1 },
    DOWN: { x: 0, y: 1 },
    LEFT: { x: -1, y: 0 },
    RIGHT: { x: 1, y: 0 },
  };

  const movement = movements[direction];
  return {
    x: current.x + movement.x,
    y: current.y + movement.y,
  };
};

export const isOppositeDirection = (current: Direction, next: Direction): boolean => {
  const opposites = {
    UP: 'DOWN',
    DOWN: 'UP',
    LEFT: 'RIGHT',
    RIGHT: 'LEFT',
  };
  return opposites[current] === next;
};