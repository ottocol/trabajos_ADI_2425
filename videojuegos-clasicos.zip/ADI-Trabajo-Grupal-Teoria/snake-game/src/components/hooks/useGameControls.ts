import { useState, useCallback } from 'react';
import { Direction } from '../types';
import { isOppositeDirection } from '../utils/movementUtils';

export function useGameControls(initialDirection: Direction) {
  const [direction, setDirection] = useState<Direction>(initialDirection);
  const [nextDirection, setNextDirection] = useState<Direction | null>(null);

  const handleDirectionChange = useCallback((newDirection: Direction) => {
    setDirection((currentDirection) => {
      if (!isOppositeDirection(currentDirection, newDirection)) {
        setNextDirection(newDirection);
        return currentDirection;
      }
      return currentDirection;
    });
  }, []);

  const processNextDirection = useCallback(() => {
    if (nextDirection && !isOppositeDirection(direction, nextDirection)) {
      setDirection(nextDirection);
      setNextDirection(null);
    }
  }, [direction, nextDirection]);

  return {
    direction,
    setDirection,
    handleDirectionChange,
    processNextDirection,
  };
}