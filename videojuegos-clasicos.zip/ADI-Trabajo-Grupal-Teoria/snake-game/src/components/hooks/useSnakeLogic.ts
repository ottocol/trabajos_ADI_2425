import { useState, useCallback } from 'react';
import { Position, Direction } from '../types';
import { isCollision } from '../utils/collisionUtils';
import { getNextPosition } from '../utils/movementUtils';

export function useSnakeLogic(onGameOver: () => void) {
  const [snake, setSnake] = useState<Position[]>([{ x: 10, y: 10 }]);

  const moveSnake = useCallback((currentDirection: Direction, food: Position) => {
    setSnake((prevSnake) => {
      const nextPosition = getNextPosition(prevSnake[0], currentDirection);

      // Check for collisions
      if (isCollision(nextPosition, prevSnake)) {
        onGameOver();
        return prevSnake;
      }

      const newSnake = [nextPosition, ...prevSnake];
      
      // Remove tail if no food was eaten
      if (!(nextPosition.x === food.x && nextPosition.y === food.y)) {
        newSnake.pop();
      }

      return newSnake;
    });
  }, [onGameOver]);

  return {
    snake,
    setSnake,
    moveSnake,
  };
}