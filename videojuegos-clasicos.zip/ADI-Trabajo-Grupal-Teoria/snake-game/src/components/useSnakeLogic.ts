import { useState, useCallback } from 'react';
import { Position, Direction, GRID_SIZE } from './types';

export function useSnakeLogic(onGameOver: () => void) {
  const [snake, setSnake] = useState<Position[]>([{ x: 10, y: 10 }]);
  const [lastProcessedDirection, setLastProcessedDirection] = useState<Direction>('RIGHT');

  const checkCollision = (head: Position) => {
    // Wall collision
    if (head.x < 0 || head.x >= GRID_SIZE || head.y < 0 || head.y >= GRID_SIZE) {
      return true;
    }

    // Self collision
    return snake.some((segment, index) => {
      if (index === 0) return false;
      return segment.x === head.x && segment.y === head.y;
    });
  };

  const moveSnake = useCallback((currentDirection: Direction, food: Position) => {
    setSnake((prevSnake) => {
      const head = { ...prevSnake[0] };

      // Only update the last processed direction after moving
      setLastProcessedDirection(currentDirection);

      switch (currentDirection) {
        case 'UP':
          head.y -= 1;
          break;
        case 'DOWN':
          head.y += 1;
          break;
        case 'LEFT':
          head.x -= 1;
          break;
        case 'RIGHT':
          head.x += 1;
          break;
      }

      if (checkCollision(head)) {
        onGameOver();
        return prevSnake;
      }

      const newSnake = [head, ...prevSnake];
      
      // Remove tail if no food was eaten
      if (!(head.x === food.x && head.y === food.y)) {
        newSnake.pop();
      }

      return newSnake;
    });
  }, []);

  return {
    snake,
    setSnake,
    moveSnake,
    lastProcessedDirection,
  };
}