import React, { useEffect } from 'react';
import { Bird } from './components/Bird';
import { Pipe } from './components/Pipe';
import { Score } from './components/Score';
import { GameOver } from './components/GameOver';
import { useGameLoop } from './hooks/useGameLoop';

function App() {
  const {
    birdPosition,
    birdRotation,
    pipes,
    score,
    highScore,
    gameOver,
    jump,
    reset,
  } = useGameLoop();

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        jump();
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [jump]);

  return (
    <div 
      className="relative w-full h-screen bg-gradient-to-b from-blue-400 to-blue-600 overflow-hidden"
      onClick={jump}
    >
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute bottom-0 w-full h-24 bg-green-800" />
      </div>

      <Bird position={birdPosition} rotation={birdRotation} />

      {pipes.map((pipe, index) => (
        <React.Fragment key={index}>
          <Pipe height={pipe.height} position={pipe.x} isTop />
          <Pipe
            height={window.innerHeight - pipe.height - 150}
            position={pipe.x}
          />
        </React.Fragment>
      ))}

      <Score score={score} highScore={highScore} />

      {gameOver && (
        <GameOver
          score={score}
          highScore={highScore}
          onRestart={reset}
        />
      )}
    </div>
  );
}

export default App;