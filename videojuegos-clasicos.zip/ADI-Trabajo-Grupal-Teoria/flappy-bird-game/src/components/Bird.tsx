import React from 'react';

interface BirdProps {
  position: number;
  rotation: number;
}

export const Bird: React.FC<BirdProps> = ({ position, rotation }) => {
  return (
    <div
      className="absolute w-8 h-8 bg-yellow-400 rounded-full"
      style={{
        top: `${position}px`,
        transform: `rotate(${rotation}deg)`,
        transition: 'transform 0.1s ease-in-out',
      }}
    >
      <div className="absolute w-3 h-3 bg-white rounded-full top-1 left-1">
        <div className="absolute w-1 h-1 bg-black rounded-full top-1 left-1" />
      </div>
      <div className="absolute w-4 h-2 bg-orange-500 right-0 top-3 rounded-r-lg" />
    </div>
  );
};