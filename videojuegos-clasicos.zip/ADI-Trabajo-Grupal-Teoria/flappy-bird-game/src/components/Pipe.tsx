import React from 'react';

interface PipeProps {
  height: number;
  position: number;
  isTop?: boolean;
}

export const Pipe: React.FC<PipeProps> = ({ height, position, isTop }) => {
  return (
    <div
      className="absolute w-16 bg-green-500 border-4 border-green-700"
      style={{
        height: `${height}px`,
        left: `${position}px`,
        top: isTop ? 0 : 'auto',
        bottom: isTop ? 'auto' : 0,
      }}
    >
      <div className={`absolute left-0 right-0 h-8 bg-green-600 border-4 border-green-700 ${isTop ? 'bottom-0' : 'top-0'}`} />
    </div>
  );
};