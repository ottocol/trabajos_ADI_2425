import React from 'react';

interface ScoreProps {
  score: number;
  highScore: number;
}

export const Score: React.FC<ScoreProps> = ({ score, highScore }) => {
  return (
    <div className="absolute top-4 left-1/2 -translate-x-1/2 text-white text-2xl font-bold flex flex-col items-center">
      <div>Score: {score}</div>
      <div className="text-sm">High Score: {highScore}</div>
    </div>
  );
};