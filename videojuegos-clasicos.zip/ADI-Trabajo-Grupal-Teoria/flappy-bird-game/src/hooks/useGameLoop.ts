import { useState, useEffect, useCallback } from 'react';

const GRAVITY = 0.4; // Reduced gravity to make the game feel smoother with lower jump
const JUMP_FORCE = -7; // Reduced from -10 to -7 for a smaller jump
const PIPE_SPEED = 3;
const PIPE_SPAWN_INTERVAL = 2000;
const GAP_SIZE = 150;

// Bird dimensions and hitbox
const BIRD_SIZE = 32;
const BIRD_HITBOX_REDUCTION = 4; // Reduce hitbox by 4px on each side

// Pipe dimensions and hitbox
const PIPE_WIDTH = 64;
const PIPE_HITBOX_REDUCTION = 8; // Reduce hitbox by 8px on each side

interface GameState {
  birdPosition: number;
  birdVelocity: number;
  birdRotation: number;
  pipes: Array<{ x: number; height: number; passed: boolean }>;
  score: number;
  highScore: number;
  gameOver: boolean;
}

export const useGameLoop = () => {
  const [gameState, setGameState] = useState<GameState>({
    birdPosition: window.innerHeight / 2,
    birdVelocity: 0,
    birdRotation: 0,
    pipes: [],
    score: 0,
    highScore: 0,
    gameOver: false,
  });

  const jump = useCallback(() => {
    if (!gameState.gameOver) {
      setGameState((prev) => ({
        ...prev,
        birdVelocity: JUMP_FORCE,
      }));
    }
  }, [gameState.gameOver]);

  const reset = useCallback(() => {
    setGameState((prev) => ({
      birdPosition: window.innerHeight / 2,
      birdVelocity: 0,
      birdRotation: 0,
      pipes: [],
      score: 0,
      highScore: prev.highScore,
      gameOver: false,
    }));
  }, []);

  useEffect(() => {
    if (gameState.gameOver) return;

    const gameLoop = setInterval(() => {
      setGameState((prev) => {
        const newBirdVelocity = prev.birdVelocity + GRAVITY;
        const newBirdPosition = prev.birdPosition + newBirdVelocity;
        const newBirdRotation = Math.min(Math.max(-30, newBirdVelocity * 4), 90);

        // Move pipes and check for passed pipes
        const newPipes = prev.pipes
          .map((pipe) => {
            const newX = pipe.x - PIPE_SPEED;
            const birdCenterX = 50 + BIRD_SIZE / 2;
            const pipeCenterX = newX + PIPE_WIDTH / 2;
            
            // Mark pipe as passed when bird passes its center
            const justPassed = !pipe.passed && birdCenterX > pipeCenterX;
            
            return {
              ...pipe,
              x: newX,
              passed: pipe.passed || justPassed,
            };
          })
          .filter((pipe) => pipe.x > -100);

        // Calculate new score based on newly passed pipes
        const newScore = prev.score + newPipes.filter(pipe => pipe.passed && !prev.pipes.find(p => p.x === pipe.x)?.passed).length;

        // Check collisions with reduced hitbox
        const birdRect = {
          top: newBirdPosition + BIRD_HITBOX_REDUCTION,
          bottom: newBirdPosition + BIRD_SIZE - BIRD_HITBOX_REDUCTION,
          left: 50 + BIRD_HITBOX_REDUCTION,
          right: 50 + BIRD_SIZE - BIRD_HITBOX_REDUCTION,
        };

        const hasCollision = newPipes.some((pipe) => {
          const topPipeRect = {
            top: 0,
            bottom: pipe.height,
            left: pipe.x + PIPE_HITBOX_REDUCTION,
            right: pipe.x + PIPE_WIDTH - PIPE_HITBOX_REDUCTION,
          };
          const bottomPipeRect = {
            top: pipe.height + GAP_SIZE,
            bottom: window.innerHeight,
            left: pipe.x + PIPE_HITBOX_REDUCTION,
            right: pipe.x + PIPE_WIDTH - PIPE_HITBOX_REDUCTION,
          };

          return (
            (birdRect.right > topPipeRect.left &&
              birdRect.left < topPipeRect.right &&
              birdRect.top < topPipeRect.bottom) ||
            (birdRect.right > bottomPipeRect.left &&
              birdRect.left < bottomPipeRect.right &&
              birdRect.bottom > bottomPipeRect.top)
          );
        });

        // Check if bird hits boundaries
        const hitsBoundary = newBirdPosition < 0 || newBirdPosition > window.innerHeight - BIRD_SIZE;

        if (hasCollision || hitsBoundary) {
          return {
            ...prev,
            gameOver: true,
            highScore: Math.max(newScore, prev.highScore),
          };
        }

        return {
          ...prev,
          birdPosition: newBirdPosition,
          birdVelocity: newBirdVelocity,
          birdRotation: newBirdRotation,
          pipes: newPipes,
          score: newScore,
        };
      });
    }, 1000 / 60);

    return () => clearInterval(gameLoop);
  }, [gameState.gameOver]);

  useEffect(() => {
    if (gameState.gameOver) return;

    const spawnPipe = setInterval(() => {
      setGameState((prev) => ({
        ...prev,
        pipes: [
          ...prev.pipes,
          {
            x: window.innerWidth,
            height: Math.random() * (window.innerHeight - GAP_SIZE - 100) + 50,
            passed: false,
          },
        ],
      }));
    }, PIPE_SPAWN_INTERVAL);

    return () => clearInterval(spawnPipe);
  }, [gameState.gameOver]);

  return {
    birdPosition: gameState.birdPosition,
    birdRotation: gameState.birdRotation,
    pipes: gameState.pipes,
    score: gameState.score,
    highScore: gameState.highScore,
    gameOver: gameState.gameOver,
    jump,
    reset,
  };
};