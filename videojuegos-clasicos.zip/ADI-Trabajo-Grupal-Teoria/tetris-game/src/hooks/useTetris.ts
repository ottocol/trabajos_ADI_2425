import { useState, useCallback, useEffect } from 'react';
import { GameState, Tetromino, TetrominoType } from '../types/tetris';
import { BOARD_WIDTH, BOARD_HEIGHT, TETROMINO_SHAPES, INITIAL_SPEED } from '../constants/tetrominos';

const createEmptyBoard = () => 
  Array(BOARD_HEIGHT).fill(null).map(() => Array(BOARD_WIDTH).fill(null));

const createRandomPiece = (): Tetromino => {
  const types: TetrominoType[] = ['I', 'J', 'L', 'O', 'S', 'T', 'Z'];
  const type = types[Math.floor(Math.random() * types.length)];
  return {
    type,
    shape: TETROMINO_SHAPES[type],
    position: { x: Math.floor(BOARD_WIDTH / 2) - 2, y: 0 },
  };
};

const checkCollision = (board: (TetrominoType | null)[][], piece: Tetromino) => {
  for (let y = 0; y < piece.shape.length; y++) {
    for (let x = 0; x < piece.shape[y].length; x++) {
      if (piece.shape[y][x]) {
        const newX = piece.position.x + x;
        const newY = piece.position.y + y;
        
        if (
          newX < 0 || 
          newX >= BOARD_WIDTH || 
          newY >= BOARD_HEIGHT ||
          (newY >= 0 && board[newY][newX] !== null)
        ) {
          return true;
        }
      }
    }
  }
  return false;
};

export const useTetris = () => {
  const [gameState, setGameState] = useState<GameState>({
    board: createEmptyBoard(),
    currentPiece: createRandomPiece(),
    nextPiece: createRandomPiece(),
    score: 0,
    level: 1,
    gameOver: false,
  });

  const mergePieceToBoard = useCallback((state: GameState) => {
    if (!state.currentPiece) return state.board;
    
    const newBoard = state.board.map(row => [...row]);
    const piece = state.currentPiece;
    
    piece.shape.forEach((row, y) => {
      row.forEach((value, x) => {
        if (value && piece.position.y + y >= 0) {
          newBoard[piece.position.y + y][piece.position.x + x] = piece.type;
        }
      });
    });
    
    return newBoard;
  }, []);

  const clearLines = useCallback((board: (TetrominoType | null)[][]) => {
    let linesCleared = 0;
    const newBoard = board.filter(row => {
      const isLineFull = row.every(cell => cell !== null);
      if (isLineFull) linesCleared++;
      return !isLineFull;
    });
    
    while (newBoard.length < BOARD_HEIGHT) {
      newBoard.unshift(Array(BOARD_WIDTH).fill(null));
    }
    
    return { newBoard, linesCleared };
  }, []);

  const moveDown = useCallback(() => {
    setGameState(prev => {
      if (prev.gameOver || !prev.currentPiece) return prev;

      const newPiece = {
        ...prev.currentPiece,
        position: {
          ...prev.currentPiece.position,
          y: prev.currentPiece.position.y + 1,
        },
      };

      if (checkCollision(prev.board, newPiece)) {
        const newBoard = mergePieceToBoard(prev);
        const { newBoard: clearedBoard, linesCleared } = clearLines(newBoard);
        const newScore = prev.score + (linesCleared * 100 * prev.level);
        const newLevel = Math.floor(newScore / 1000) + 1;

        if (prev.currentPiece.position.y <= 0) {
          return { ...prev, board: newBoard, gameOver: true };
        }

        return {
          ...prev,
          board: clearedBoard,
          currentPiece: prev.nextPiece,
          nextPiece: createRandomPiece(),
          score: newScore,
          level: newLevel,
        };
      }

      return { ...prev, currentPiece: newPiece };
    });
  }, [clearLines, mergePieceToBoard]);

  const move = useCallback((direction: 'left' | 'right') => {
    setGameState(prev => {
      if (prev.gameOver || !prev.currentPiece) return prev;

      const newPiece = {
        ...prev.currentPiece,
        position: {
          ...prev.currentPiece.position,
          x: prev.currentPiece.position.x + (direction === 'left' ? -1 : 1),
        },
      };

      if (checkCollision(prev.board, newPiece)) return prev;
      return { ...prev, currentPiece: newPiece };
    });
  }, []);

  const rotate = useCallback(() => {
    setGameState(prev => {
      if (prev.gameOver || !prev.currentPiece) return prev;

      const newShape = prev.currentPiece.shape[0].map((_, index) =>
        prev.currentPiece!.shape.map(row => row[index]).reverse()
      );

      const newPiece = {
        ...prev.currentPiece,
        shape: newShape,
      };

      if (checkCollision(prev.board, newPiece)) return prev;
      return { ...prev, currentPiece: newPiece };
    });
  }, []);

  const drop = useCallback(() => {
    setGameState(prev => {
      if (prev.gameOver || !prev.currentPiece) return prev;

      let newPiece = prev.currentPiece;
      while (!checkCollision(prev.board, {
        ...newPiece,
        position: { ...newPiece.position, y: newPiece.position.y + 1 },
      })) {
        newPiece = {
          ...newPiece,
          position: { ...newPiece.position, y: newPiece.position.y + 1 },
        };
      }

      const newBoard = mergePieceToBoard({ ...prev, currentPiece: newPiece });
      const { newBoard: clearedBoard, linesCleared } = clearLines(newBoard);
      const newScore = prev.score + (linesCleared * 100 * prev.level);
      const newLevel = Math.floor(newScore / 1000) + 1;

      return {
        ...prev,
        board: clearedBoard,
        currentPiece: prev.nextPiece,
        nextPiece: createRandomPiece(),
        score: newScore,
        level: newLevel,
      };
    });
  }, [clearLines, mergePieceToBoard]);

  const reset = useCallback(() => {
    setGameState({
      board: createEmptyBoard(),
      currentPiece: createRandomPiece(),
      nextPiece: createRandomPiece(),
      score: 0,
      level: 1,
      gameOver: false,
    });
  }, []);

  return {
    gameState,
    moveDown,
    move,
    rotate,
    drop,
    reset,
  };
};