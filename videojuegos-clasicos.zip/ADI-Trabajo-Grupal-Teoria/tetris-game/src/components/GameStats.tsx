import React from 'react';

interface GameStatsProps {
  score: number;
  level: number;
}

export const GameStats: React.FC<GameStatsProps> = ({ score, level }) => {
  return (
    <div className="bg-gray-900 p-4 rounded-lg text-white">
      <div className="mb-4">
        <h2 className="text-lg font-bold mb-1">Score</h2>
        <p className="text-2xl font-bold">{score}</p>
      </div>
      <div>
        <h2 className="text-lg font-bold mb-1">Level</h2>
        <p className="text-2xl font-bold">{level}</p>
      </div>
    </div>
  );
};