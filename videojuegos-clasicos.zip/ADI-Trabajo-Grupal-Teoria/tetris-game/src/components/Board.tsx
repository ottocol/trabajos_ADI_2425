import React from 'react';
import { TetrominoType } from '../types/tetris';
import { COLORS } from '../constants/tetrominos';

interface BoardProps {
  board: (TetrominoType | null)[][];
  currentPiece: {
    shape: boolean[][];
    position: { x: number; y: number };
    type: TetrominoType;
  } | null;
}

export const Board: React.FC<BoardProps> = ({ board, currentPiece }) => {
  const renderCell = (cell: TetrominoType | null, rowIndex: number, colIndex: number) => {
    let content = cell;

    if (currentPiece) {
      const pieceX = colIndex - currentPiece.position.x;
      const pieceY = rowIndex - currentPiece.position.y;

      if (
        pieceX >= 0 &&
        pieceX < currentPiece.shape[0].length &&
        pieceY >= 0 &&
        pieceY < currentPiece.shape.length &&
        currentPiece.shape[pieceY][pieceX]
      ) {
        content = currentPiece.type;
      }
    }

    return (
      <div
        key={`${rowIndex}-${colIndex}`}
        className={`w-6 h-6 border border-gray-700 ${
          content ? COLORS[content] : 'bg-gray-900'
        }`}
      />
    );
  };

  return (
    <div className="inline-block bg-gray-900 p-2 rounded-lg">
      {board.map((row, rowIndex) => (
        <div key={rowIndex} className="flex">
          {row.map((cell, colIndex) => renderCell(cell, rowIndex, colIndex))}
        </div>
      ))}
    </div>
  );
};