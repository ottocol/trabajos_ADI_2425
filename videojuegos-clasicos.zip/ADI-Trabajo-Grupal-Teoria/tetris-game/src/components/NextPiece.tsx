import React from 'react';
import { Tetromino } from '../types/tetris';
import { COLORS } from '../constants/tetrominos';

interface NextPieceProps {
  piece: Tetromino | null;
}

export const NextPiece: React.FC<NextPieceProps> = ({ piece }) => {
  if (!piece) return null;

  return (
    <div className="bg-gray-900 p-4 rounded-lg">
      <h2 className="text-white text-lg font-bold mb-2">Next Piece</h2>
      <div className="inline-block">
        {piece.shape.map((row, y) => (
          <div key={y} className="flex">
            {row.map((cell, x) => (
              <div
                key={`${y}-${x}`}
                className={`w-6 h-6 border border-gray-700 ${
                  cell ? COLORS[piece.type] : 'bg-gray-900'
                }`}
              />
            ))}
          </div>
        ))}
      </div>
    </div>
  );
};