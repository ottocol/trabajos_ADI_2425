import React, { useEffect, useCallback } from 'react';
import { Board } from './components/Board';
import { NextPiece } from './components/NextPiece';
import { GameStats } from './components/GameStats';
import { useTetris } from './hooks/useTetris';
import { Gamepad } from 'lucide-react';

function App() {
  const { gameState, moveDown, move, rotate, drop, reset } = useTetris();

  const handleKeyDown = useCallback(
    (event: KeyboardEvent) => {
      if (gameState.gameOver) return;

      switch (event.key) {
        case 'ArrowLeft':
          move('left');
          break;
        case 'ArrowRight':
          move('right');
          break;
        case 'ArrowDown':
          moveDown();
          break;
        case 'ArrowUp':
          rotate();
          break;
        case ' ':
          drop();
          break;
        default:
          break;
      }
    },
    [gameState.gameOver, move, moveDown, rotate, drop]
  );

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [handleKeyDown]);

  useEffect(() => {
    if (gameState.gameOver) return;

    const interval = setInterval(() => {
      moveDown();
    }, Math.max(100, 1000 - (gameState.level - 1) * 100));

    return () => {
      clearInterval(interval);
    };
  }, [gameState.level, gameState.gameOver, moveDown]);

  return (
    <div className="min-h-screen bg-gray-800 flex items-center justify-center">
      <div className="p-8 bg-gray-700 rounded-xl shadow-2xl">
        <div className="flex items-center justify-center mb-8">
          <Gamepad className="w-8 h-8 text-white mr-2" />
          <h1 className="text-4xl font-bold text-white">Tetris</h1>
        </div>

        <div className="flex gap-8">
          <div>
            <Board board={gameState.board} currentPiece={gameState.currentPiece} />
          </div>
          
          <div className="space-y-6">
            <NextPiece piece={gameState.nextPiece} />
            <GameStats score={gameState.score} level={gameState.level} />
            
            {gameState.gameOver && (
              <div className="text-center">
                <p className="text-xl font-bold text-red-500 mb-4">Game Over!</p>
                <button
                  onClick={reset}
                  className="bg-indigo-500 text-white px-4 py-2 rounded-lg hover:bg-indigo-600 transition-colors"
                >
                  Play Again
                </button>
              </div>
            )}

            <div className="bg-gray-900 p-4 rounded-lg text-white">
              <h2 className="text-lg font-bold mb-2">Controls</h2>
              <ul className="space-y-1 text-sm">
                <li>← → : Move</li>
                <li>↑ : Rotate</li>
                <li>↓ : Move Down</li>
                <li>Space : Drop</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;