query_get_issues_from_project = '''
    query getIssuesFromProject($projectId: ID!, $afterCursor: String) {
      node(id: $projectId) {
        ... on ProjectV2 {
          items(first: 100, after: $afterCursor) {
            nodes {
              id
              content {
                ... on Issue {
                  id
                  title
                  number
                  url
                  updatedAt
                  assignees(first: 10) {
                    nodes {
                      login
                    }
                  }
                  labels(first: 10) {
                    nodes {
                      name
                      color
                    }
                  }
                  milestone {
                    title
                  }
                  state
                  repository {
                    name
                  }
                }
                ... on PullRequest {
                  id
                  title
                  number
                  url
                  updatedAt
                  assignees(first: 10) {
                    nodes {
                      login
                    }
                  }
                  labels(first: 10) {
                    nodes {
                      name
                      color
                    }
                  }
                  milestone {
                    title
                  }
                  state
                  repository {
                    name
                  }
                }
              }
            }
            pageInfo {
              hasNextPage
              endCursor
            }
          }
        }
      }
    }
    '''


