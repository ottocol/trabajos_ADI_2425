mutation_set_estimate = '''
        mutation setEstimateField($itemId: ID!, $projectId: ID!, $fieldId: ID!, $estimate: Float) {
          updateProjectV2ItemFieldValue(
            input: {fieldId: $fieldId, itemId: $itemId, projectId: $projectId, value: {number: $estimate}}
          ) {
            projectV2Item {
              id
            }
          }
        }
        '''

mutation_add_issue = '''
   mutation addIssueToProject($issueId: ID!, $projectId: ID!) {
     addProjectV2ItemById(input: {contentId: $issueId, projectId: $projectId}) {
       item {
         id
       }
     }
   }
   '''

