import json
import sys
from datetime import datetime
import pytz
import time
import random

from graphqlclient import GraphQLClient
from graphql_lib import mutations_for_custom_fields, queries_migrations
GH_API_TOKEN = ""


def get_project_issues(pj_id):
    client = GraphQLClient("https://api.github.com/graphql")
    client.inject_token(GH_API_TOKEN)
    issues = []
    has_next_page = True
    cursor = None

    while has_next_page:
        res = client.execute(queries_migrations.query_get_issues_from_project, {"projectId": pj_id, "afterCursor": cursor})

        if res:
            data = json.loads(res)

            page_issues = data['data']['node']['items']['nodes']
            issues.extend(page_issues)

            page_info = data['data']['node']['items']['pageInfo']
            has_next_page = page_info['hasNextPage']
            cursor = page_info['endCursor']
        else:
            break

    return issues

def add_issue_to_project(issue_id, project_id):
    client = GraphQLClient("https://api.github.com/graphql")
    client.inject_token(GH_API_TOKEN)


    variables = {"issueId": issue_id, "projectId": project_id}
    res = client.execute(mutations_for_custom_fields.mutation_add_issue, variables)
    item_data = json.loads(res)
    item_id = item_data['data']['addProjectV2ItemById']['item']['id']
    print(f"Added new item {issue_id} to project {project_id} with item ID {item_id}")

    return res

def remove_issue_from_project(issue_node_id, project_id):
    client = GraphQLClient("https://api.github.com/graphql")
    client.inject_token(GH_API_TOKEN)

    mutation_remove_issue = '''
    mutation removeIssueFromProject($projectId: ID!, $itemId: ID!) {
      deleteProjectV2Item(input: {projectId: $projectId, itemId: $itemId}) {
        deletedItemId
      }
    }
    '''

    variables = {
        "projectId": project_id,
        "itemId": issue_node_id
    }
    res = client.execute(mutation_remove_issue, variables)
    print(f"Removing the item {issue_node_id} from project {project_id}")
    return res


def check_rate_limit():
    client = GraphQLClient("https://api.github.com/graphql")
    client.inject_token(f"{GH_API_TOKEN}")


    query_rate_limit = '''
    query {
      rateLimit {
        limit
        cost
        remaining
        resetAt
      }
    }
    '''

    result = client.execute(query_rate_limit)

    if result:
        data = json.loads(result)
        rate_limit_info = data['data']['rateLimit']
        return rate_limit_info
    else:
        print("No se pudo obtener información del límite de uso. Verifica la conexión y el token.")
        return None

def convert_to_madrid_spain_timezone(utc_time_str):
    utc_time = datetime.strptime(utc_time_str, "%Y-%m-%dT%H:%M:%SZ")
    utc_time = utc_time.replace(tzinfo=pytz.UTC)

    madrid_tz = pytz.timezone("Europe/Madrid")

    madrid_time = utc_time.astimezone(madrid_tz)

    return madrid_time.strftime("%H:%M:%S")

def migrate_issues_to_new_project(source_project_id, target_project_id, test_mode):
    issues = get_project_issues(source_project_id)
    completed_issues = 0

    if test_mode is not None:
        issues = issues[:3]

    total_number_of_issues = len(issues)
    print(f"Items to be transferred: {total_number_of_issues}")

    for issue in issues:
        rate_limit = check_rate_limit()
        if rate_limit['remaining'] < 30:
            recover_time = rate_limit['resetAt']
            print("*************************************************************************************************************************************************************************************")
            print("*************************************************************************************************************************************************************************************")

            print(f"Your token has not enough request left, it will be again available today at {convert_to_madrid_spain_timezone(recover_time)} (MADRID, SPAIN TIMEZONE)")
            print(f"Expected items to be transferred: {total_number_of_issues}")
            print(f"Transferred items: {completed_issues}")
            print(f"Remaining items to be transferred: {total_number_of_issues - completed_issues}")

            print("*************************************************************************************************************************************************************************************")
            print("*************************************************************************************************************************************************************************************")
            sys.exit(0)

        print("*************************************************************************************************************")
        print("The following item of the origin project is going to be transferred:")
        print(f"Title:", issue["content"]["title"], "\n")
        # print("Assignees:", [assignee["login"] for assignee in issue["content"]["assignees"]["nodes"]])

        issue_id = issue['content']['id']
        issue_node_id = issue['id']

        issue_data = {
            "issue_id": issue_id,
            "issue_node_id": issue_node_id,
            "title": issue["content"]["title"]
        }

        try:
            add_issue_to_project(issue_id, target_project_id)
            remove_issue_from_project(issue_node_id, source_project_id)

            completed_issues += 1
            print(f"Transferred {completed_issues} out of {total_number_of_issues} items")
            print("*************************************************************************************************************")
        except Exception as e:
            print(f"Error transferring issue {issue_id}: {e}")
            print("Please look file 'item_that_failed.json' in order to see all the information of the failed transferred item. Save this file in order to keep all the information of the item")
            with open("item_that_failed.json", "w") as f:
                json.dump(issue_data, f, indent=4)
            sys.exit(1)

        time.sleep(random.uniform(1, 3))

    return issues

def main_migration_script(user_token, origin_project_id, destiny_project_id, test_mode):
    global GH_API_TOKEN
    token = user_token
    GH_API_TOKEN = f"Bearer {token}"

    source_project_id = origin_project_id
    target_project_id = destiny_project_id

    migrate_issues_to_new_project(source_project_id, target_project_id, test_mode)
