# Proyecto de Migración de Issues en GitHub

Este proyecto permite migrar issues de un proyecto a otro dentro de una organización en GitHub utilizando la API GraphQL de GitHub.

## Requisitos Previos
- Python instalado (versión 3.11).
- Token de Acceso a la API de GitHub con permisos suficientes para acceder y modificar proyectos dentro de la organización.

## Librerías Necesarias
- `graphqlclient`: se utiliza para realizar consultas y mutaciones GraphQL en GitHub.
Para instalar las librerías necesarias, ejecuta:

```
pip install -r requirements.txt
```

## Configuración Inicial
Antes de ejecutar el código, debes:

Accder al fichero config.json para modificar tus parametros de ejecucion

## Ejecución del Código
Para lanzar el script principal de migración, utiliza:
```
python migration_script.py
```
