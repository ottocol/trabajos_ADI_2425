import json
import sys
from graphqlclient import GraphQLClient
from migration_script import main_migration_script

try:
    with open("config.json", "r") as config_file:
        config = json.load(config_file)
        GH_API_TOKEN = config.get("GH_API_TOKEN")
        org_name = config.get("org_name")
        test_mode = config.get("test_mode", None)
except FileNotFoundError:
    print("Error: config.json file not found.")
    sys.exit(-1)
except json.JSONDecodeError:
    print("Error: config.json file is not properly formatted.")
    sys.exit(-1)

if not GH_API_TOKEN or not org_name:
    print("Error: GH_API_TOKEN or org_name is missing in config.json.")
    sys.exit(-1)

query_get_all_projects = '''
query getAllProjects($orgName: String!, $after: String) {
  organization(login: $orgName) {
    projectsV2(first: 100, after: $after) {
      nodes {
        id
        title
        number
      }
      pageInfo {
        hasNextPage
        endCursor
      }
    }
  }
}
'''


def get_all_projects(org_name):
    client = GraphQLClient("https://api.github.com/graphql")
    client.inject_token(f"Bearer {GH_API_TOKEN}")

    projects_list = []
    has_next_page = True
    after_cursor = None

    while has_next_page:
        variables = {"orgName": org_name, "after": after_cursor}
        result = client.execute(query_get_all_projects, variables)

        if result:
            data = json.loads(result)
            projects = data['data']['organization']['projectsV2']['nodes']
            page_info = data['data']['organization']['projectsV2']['pageInfo']

            for project in projects:
                project_info = {
                    "Project Name": project['title'],
                    "Project ID": project['id'],
                    "Project Number": project['number']
                }
                projects_list.append(project_info)

            has_next_page = page_info['hasNextPage']
            after_cursor = page_info['endCursor'] if has_next_page else None
        else:
            print("No se recibió respuesta para la lista de proyectos. Verifica la conexión y el token.")
            return None

    return projects_list

def get_project_id_and_name(project_wanted):
    selected_project = -1
    wrong_option = False
    while wrong_option or selected_project < 0 or selected_project > counter:
        selected_project = input(f"Please introduce the number of the {project_wanted} project (choose from 0 to {counter}) \n")
        try:
            wrong_option = False
            selected_project = int(selected_project)
        except:
            wrong_option = True
            print(f"It is mandatory to introduce a number from 0 to {counter}\n")

    return all_projects[selected_project]["Project ID"], all_projects[selected_project]["Project Name"]

if __name__ == "__main__":
    output_data = {
        "Projects": [],
        "Fields": {}
    }

    try:
        all_projects = get_all_projects(org_name)
    except:
        print("Something went wrong, please check the org name")
        sys.exit(-1)
    if all_projects:
        output_data["Projects"] = all_projects

        counter = 0
        print("############################################################")
        print("############################################################")
        for project in output_data["Projects"]:
            project_name = project["Project Name"]
            print(f"{counter}) {project_name}")
            counter += 1
        print("############################################################")
        print("############################################################")
        counter -= 1

        origin_project_id, origin_project_name = get_project_id_and_name("origin")

        destiny_project_id, destiny_project_name = get_project_id_and_name("destiny")

        confirmation = False
        decision = ""
        while confirmation is False:
            decision = input(f"You are going to transfer all issues from project {origin_project_name} to {destiny_project_name}, if you are sure please write CONTINUE if not write CANCEL \n")
            if decision == "CONTINUE":
                confirmation = True
            if decision == "CANCEL":
                print("Operation has been canceled")
                sys.exit(0)

        main_migration_script(GH_API_TOKEN, origin_project_id, destiny_project_id, test_mode)
